import Header from "@/components/header"
import HeroSection from "@/components/hero-section"
import PossibilitiesSection from "@/components/possibilities-section"
import ProblemSection from "@/components/problem-section"
import SolutionSection from "@/components/solution-section"
import ValueStackSection from "@/components/value-stack-section"
import TestimonialsSection from "@/components/testimonials-section"
import ScarcitySection from "@/components/scarcity-section"
import GuaranteeSection from "@/components/guarantee-section"
import FaqSection from "@/components/faq-section"
import ServiceBreakdown from "@/components/service-breakdown"
import FinalCta from "@/components/final-cta"
import Footer from "@/components/footer"

export default function Home() {
  return (
    <main className="min-h-screen font-sans bg-navy-950 text-white">
      <Header />
      <HeroSection />
      <PossibilitiesSection />
      <ProblemSection />
      <SolutionSection />
      <ValueStackSection />
      <TestimonialsSection />
      <ScarcitySection />
      <GuaranteeSection />
      <FaqSection />
      <ServiceBreakdown />
      <FinalCta />
      <Footer />
    </main>
  )
}

