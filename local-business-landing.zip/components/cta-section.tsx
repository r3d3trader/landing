import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Link from "next/link"

export default function CTASection() {
  return (
    <section className="py-16 bg-slate-900 text-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="max-w-3xl mx-auto text-center space-y-6">
          <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
            Ready to Transform Your Local Business?
          </h2>
          <p className="text-xl text-slate-300">
            Take the first step toward growing your customer base and increasing your revenue.
          </p>

          <div className="max-w-md mx-auto">
            <form className="space-y-4">
              <Input
                type="email"
                placeholder="Enter your email"
                className="bg-white/10 border-white/20 text-white placeholder:text-slate-400"
              />
              <Button size="lg" className="w-full bg-emerald-600 hover:bg-emerald-700">
                Schedule a Free Consultation
              </Button>
            </form>
            <p className="mt-4 text-sm text-slate-400">
              By submitting this form, you agree to our{" "}
              <Link href="/terms" className="underline underline-offset-2 hover:text-white">
                Terms & Conditions
              </Link>{" "}
              and{" "}
              <Link href="/privacy" className="underline underline-offset-2 hover:text-white">
                Privacy Policy
              </Link>
            </p>
          </div>

          <div className="pt-6">
            <p className="font-medium">Questions? Call us at (555) 123-4567</p>
          </div>
        </div>
      </div>
    </section>
  )
}

