"use client"

import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

const faqs = [
  {
    question: "How much time will implementing your marketing system take?",
    answer:
      "Our system is designed to integrate seamlessly with your business operations. Most clients spend about 1-2 hours per week reviewing progress and providing feedback. Our team handles the heavy lifting of implementation and management.",
  },
  {
    question: "How long before I see results?",
    answer:
      "While results vary by business and market, most clients begin seeing measurable improvements within 30-60 days. Our comprehensive approach builds momentum over time, with the most significant results typically appearing after 90 days of consistent implementation.",
  },
  {
    question: "Is your service specifically designed for local businesses?",
    answer:
      "Yes, our entire system is built specifically for local businesses. We understand the unique challenges and opportunities of local marketing, and our strategies are tailored to help you connect with your community and stand out in your specific market.",
  },
  {
    question: "What makes your service different from other marketing agencies?",
    answer:
      "We specialize exclusively in local business marketing with a proven system refined over years of working with businesses like yours. Our comprehensive approach integrates website optimization, local SEO, reputation management, and marketing automation into a cohesive strategy designed for sustainable growth.",
  },
  {
    question: "Do you offer a satisfaction guarantee?",
    answer:
      "Yes, we stand behind our service with a satisfaction guarantee. If you're not seeing the expected results after following our program for 90 days, we'll provide an additional month of service at no charge while we work together to adjust the strategy for your specific situation.",
  },
]

export default function FAQAccordion() {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Frequently Asked Questions</h2>
          <p className="mt-4 text-xl text-slate-600 max-w-3xl mx-auto">
            Get answers to common questions about our local business marketing program.
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`}>
                <AccordionTrigger className="text-left text-lg font-medium">{faq.question}</AccordionTrigger>
                <AccordionContent className="text-slate-600">{faq.answer}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  )
}

