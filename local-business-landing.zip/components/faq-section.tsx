"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { ChevronDown, ChevronUp } from "lucide-react"

const faqs = [
  {
    question: "I'm too busy—how much time will this take?",
    answer:
      "Our system seamlessly integrates into your daily routine in just 15 minutes—less time than scrolling through social media! We handle all the heavy lifting while you focus on running your business.",
  },
  {
    question: "What if I don't see results?",
    answer:
      "Our 'Risk-Reversal Rocket Guarantee' ensures that you see measurable improvements in 90 days or get extra coaching—and your money back. We're confident in our system because it's been proven with over 1,200 local businesses.",
  },
  {
    question: "Is this really designed for local businesses?",
    answer:
      "Absolutely—every strategy, tool, and design element is custom-tailored to boost your local presence and drive community engagement. We specialize exclusively in helping local businesses thrive in their specific markets.",
  },
  {
    question: "How long before I start seeing results?",
    answer:
      "Most clients begin seeing initial results within the first 30 days, with significant improvements by day 60, and transformative results by day 90. Our system is designed to build momentum that continues to grow over time.",
  },
  {
    question: "Do I need technical skills to implement this?",
    answer:
      "Not at all. Our team handles all the technical aspects of implementation. You'll have a dedicated account manager who ensures everything runs smoothly, and our systems are designed to be user-friendly even for those with minimal technical experience.",
  },
  {
    question: "How is this different from other marketing services?",
    answer:
      "Unlike generic marketing services, our Breakthrough 90 Blueprint is specifically designed for local businesses with proven strategies that work in local markets. We offer a comprehensive solution that includes website optimization, marketing automation, AI assistance, and personalized strategy—all backed by our risk-free guarantee.",
  },
]

export default function FaqSection() {
  const [openIndex, setOpenIndex] = useState(null)

  const toggleFaq = (index) => {
    setOpenIndex(openIndex === index ? null : index)
  }

  return (
    <section id="faq" className="py-20 bg-navy-950">
      <div className="container mx-auto px-4">
        <motion.div
          className="text-center max-w-3xl mx-auto mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-white">Overcoming Your Concerns</h2>
          <p className="text-lg text-gray-300">Get answers to the most common questions about our Elite program.</p>
        </motion.div>

        <div className="max-w-3xl mx-auto space-y-4">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              className={`bg-navy-900 rounded-lg overflow-hidden border ${openIndex === index ? "border-blue-500/30" : "border-navy-800"} transition-all duration-300`}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <button
                className="w-full px-6 py-4 flex justify-between items-center text-left"
                onClick={() => toggleFaq(index)}
              >
                <h3 className="text-lg font-bold text-white">{faq.question}</h3>
                {openIndex === index ? (
                  <ChevronUp className="w-5 h-5 text-blue-400 flex-shrink-0" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-gray-400 flex-shrink-0" />
                )}
              </button>

              <div
                className={`px-6 overflow-hidden transition-all duration-300 ${
                  openIndex === index ? "max-h-96 pb-6" : "max-h-0"
                }`}
              >
                <p className="text-gray-300">{faq.answer}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

