"use client"

import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ArrowRight, CheckCircle } from "lucide-react"

export default function FinalCta() {
  return (
    <section id="contact" className="py-20 bg-navy-950">
      <div className="container mx-auto px-4">
        <motion.div
          className="text-center max-w-3xl mx-auto mb-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-white">Ready to Dominate Your Local Market?</h2>
          <p className="text-lg text-gray-300">
            Don't wait—your community is ready for you to lead the way. Act now and join the ranks of local business
            elites transforming their market presence!
          </p>
        </motion.div>

        <motion.div
          className="max-w-2xl mx-auto bg-navy-900 rounded-xl p-8 border border-navy-800"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <h3 className="text-2xl font-bold mb-6 text-center text-white">Take Our 10-Second Quick Quiz</h3>

          <form className="space-y-6">
            <div className="space-y-4">
              <div>
                <label className="text-gray-300 mb-1 block">Your Name</label>
                <Input
                  type="text"
                  placeholder="Enter your full name"
                  className="bg-navy-800 border-navy-700 text-white placeholder:text-gray-500"
                />
              </div>

              <div>
                <label className="text-gray-300 mb-1 block">Your Email</label>
                <Input
                  type="email"
                  placeholder="Enter your email address"
                  className="bg-navy-800 border-navy-700 text-white placeholder:text-gray-500"
                />
              </div>

              <div>
                <label className="text-gray-300 mb-1 block">Your Business Type</label>
                <select className="w-full rounded-md bg-navy-800 border-navy-700 text-white p-2">
                  <option value="" className="bg-navy-900">
                    Select your business type
                  </option>
                  <option value="retail" className="bg-navy-900">
                    Retail Store
                  </option>
                  <option value="restaurant" className="bg-navy-900">
                    Restaurant/Café
                  </option>
                  <option value="service" className="bg-navy-900">
                    Service Business
                  </option>
                  <option value="professional" className="bg-navy-900">
                    Professional Practice
                  </option>
                  <option value="other" className="bg-navy-900">
                    Other
                  </option>
                </select>
              </div>
            </div>

            <div className="space-y-2">
              <p className="text-gray-300 font-medium">What's your biggest challenge right now?</p>

              {[
                "Getting more customers/clients",
                "Converting leads into sales",
                "Standing out from competitors",
                "Managing my online presence",
                "Automating my marketing",
              ].map((option, index) => (
                <label key={index} className="flex items-center gap-2 cursor-pointer">
                  <input type="radio" name="challenge" className="text-blue-500" />
                  <span className="text-gray-300">{option}</span>
                </label>
              ))}
            </div>

            <Button className="w-full bg-blue-500 hover:bg-blue-600 text-white font-bold rounded-md py-6 text-lg flex items-center justify-center gap-2 group">
              Secure Your Elite Spot Now
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Button>

            <div className="text-center text-sm text-gray-400">
              <p>Only 5 spots remaining! Secure yours before they're gone.</p>
              <div className="flex items-center justify-center gap-2 mt-2">
                <CheckCircle className="w-4 h-4 text-blue-400" />
                <span>Your information is secure and will never be shared</span>
              </div>
            </div>
          </form>
        </motion.div>
      </div>
    </section>
  )
}

