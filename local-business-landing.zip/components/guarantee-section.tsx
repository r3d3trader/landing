"use client"

import { motion } from "framer-motion"
import { Shield, Check } from "lucide-react"

export default function GuaranteeSection() {
  return (
    <section className="py-20 bg-navy-900">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <motion.div
            className="text-center mb-12"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-white">Our Ironclad Promise</h2>
            <p className="text-lg text-gray-300">
              We stand behind our service with a guarantee that eliminates all risk.
            </p>
          </motion.div>

          <motion.div
            className="bg-navy-800 rounded-xl p-8 border border-navy-700 flex flex-col md:flex-row gap-8 items-center"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <div className="w-32 h-32 rounded-full bg-blue-500/20 flex items-center justify-center flex-shrink-0 mx-auto md:mx-0 border border-blue-500/30">
              <Shield className="w-16 h-16 text-blue-400" />
            </div>

            <div>
              <h3 className="text-2xl font-bold text-white mb-4 text-center md:text-left">
                Risk-Reversal Rocket Guarantee
              </h3>
              <p className="text-lg text-gray-300 mb-6">
                Our 'Risk-Reversal Rocket Guarantee': Achieve measurable improvements in lead conversion within 90 days
                or receive an extra month of personalized coaching absolutely free—plus, get a full refund if you're not
                completely satisfied.
              </p>
              <p className="text-lg text-gray-300">
                This guarantee eliminates all risk, giving you complete confidence in the transformation we deliver.
              </p>

              <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                {[
                  "90-day performance window",
                  "Measurable improvements guaranteed",
                  "Free extra month if not satisfied",
                  "Full refund option available",
                ].map((item, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <Check className="w-5 h-5 text-blue-400" />
                    <span className="text-gray-300">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

