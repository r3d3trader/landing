"use client"

import { useState } from "react"
import Link from "next/link"
import { Menu, X, Mail } from "lucide-react"
import { motion } from "framer-motion"

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 bg-navy-950/90 backdrop-blur-md border-b border-navy-800">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-md bg-blue-500 flex items-center justify-center text-white font-bold text-xl">
            B
          </div>
          <span className="text-xl font-bold text-white">Breakthrough</span>
        </Link>

        <div className="hidden md:flex items-center gap-4">
          <Link
            href="mailto:support@yourbrand.com"
            className="flex items-center gap-2 text-gray-300 hover:text-white transition-colors"
          >
            <Mail className="w-4 h-4" />
            <span>support@yourbrand.com</span>
          </Link>
        </div>

        {/* Mobile Menu Button */}
        <button className="md:hidden text-white" onClick={() => setIsMenuOpen(!isMenuOpen)}>
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <motion.div
          className="md:hidden bg-navy-900 border-b border-navy-800"
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: "auto", opacity: 1 }}
          exit={{ height: 0, opacity: 0 }}
          transition={{ duration: 0.3 }}
        >
          <div className="container mx-auto px-4 py-4 flex flex-col gap-4">
            <Link
              href="#"
              className="text-gray-300 hover:text-white transition-colors font-medium py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              Home
            </Link>
            <Link
              href="#features"
              className="text-gray-300 hover:text-white transition-colors font-medium py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              Features
            </Link>
            <Link
              href="#testimonials"
              className="text-gray-300 hover:text-white transition-colors font-medium py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              Testimonials
            </Link>
            <Link
              href="#faq"
              className="text-gray-300 hover:text-white transition-colors font-medium py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              FAQ
            </Link>
            <Link
              href="#contact"
              className="text-gray-300 hover:text-white transition-colors font-medium py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              Contact
            </Link>
            <Link
              href="mailto:support@yourbrand.com"
              className="flex items-center gap-2 text-gray-300 hover:text-white transition-colors py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              <Mail className="w-4 h-4" />
              <span>support@yourbrand.com</span>
            </Link>
          </div>
        </motion.div>
      )}
    </header>
  )
}

