"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { motion } from "framer-motion"
import { Play } from "lucide-react"

export default function HeroSection() {
  const [videoOpen, setVideoOpen] = useState(false)

  return (
    <section className="py-20 md:py-32 bg-navy-950 relative overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-radial from-blue-900/20 to-transparent opacity-30"></div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-6"
          >
            <span className="text-blue-500 font-medium tracking-wider text-sm md:text-base uppercase">
              THE #1 SOLUTION FOR LOCAL BUSINESSES
            </span>
          </motion.div>

          <motion.h1
            className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            Unlock Your Local Business Breakthrough
          </motion.h1>

          <motion.p
            className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            Double Your Customer Base in 90 Days or Keep Your Money Back – Only 25 Exclusive Spots Available!
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <Button className="bg-blue-500 hover:bg-blue-600 text-white font-medium rounded-md px-8 py-6 text-lg">
              Take Our 10-Second Quick Quiz
            </Button>
          </motion.div>

          <motion.div
            className="mt-20 relative"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <div className="aspect-video max-w-3xl mx-auto bg-navy-900/50 rounded-lg border border-navy-800 flex items-center justify-center cursor-pointer hover:bg-navy-900 transition-colors relative overflow-hidden">
              {/* Video thumbnail */}
              <div className="absolute inset-0 bg-gradient-to-t from-navy-950/80 to-transparent"></div>

              {/* Play button */}
              <button
                onClick={() => setVideoOpen(true)}
                className="w-16 h-16 md:w-20 md:h-20 bg-blue-500 hover:bg-blue-600 rounded-full flex items-center justify-center transition-colors z-10"
              >
                <Play className="w-6 h-6 md:w-8 md:h-8 text-white ml-1" />
              </button>

              {/* Video title */}
              <div className="absolute bottom-4 left-4 right-4 text-left">
                <h3 className="text-lg md:text-xl font-medium">See How We Transform Local Businesses</h3>
                <p className="text-sm text-gray-300">Watch our 3-minute explainer video</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

