"use client"

import { motion } from "framer-motion"
import { TrendingUp, Zap, Clock } from "lucide-react"

export default function PossibilitiesSection() {
  const features = [
    {
      icon: <TrendingUp className="w-6 h-6 text-blue-500" />,
      title: "Steady Growth",
      description: "A consistent stream of local clients flowing into your business",
    },
    {
      icon: <Zap className="w-6 h-6 text-blue-500" />,
      title: "High Conversion",
      description: "A website that turns visitors into paying customers",
    },
    {
      icon: <Clock className="w-6 h-6 text-blue-500" />,
      title: "24/7 Automation",
      description: "Systems that work around the clock while you focus on your business",
    },
  ]

  return (
    <section className="py-20 bg-navy-900">
      <div className="container mx-auto px-4">
        <motion.div
          className="text-center max-w-3xl mx-auto mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-white">Imagine the Possibilities</h2>
          <p className="text-lg text-gray-300">
            Imagine a thriving business with a steady stream of local clients, a state-of-the-art website that converts
            visitors into buyers, and automation systems that work around the clock—all without the stress or wasted ad
            spend. Your community will take notice, and your success will speak for itself.
          </p>
          <p className="text-lg text-gray-300 mt-4">
            Future pace your transformation: no more scattered systems or missed opportunities—just an integrated,
            high-performance solution tailored for your local market.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              className="bg-navy-800 rounded-xl p-6 border border-navy-700 hover:border-blue-500/30 transition-all"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <div className="w-14 h-14 bg-navy-700 rounded-full flex items-center justify-center mb-6">
                {feature.icon}
              </div>
              <h3 className="text-xl font-bold mb-3 text-white">{feature.title}</h3>
              <p className="text-gray-300">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

