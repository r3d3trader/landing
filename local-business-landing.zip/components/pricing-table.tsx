import { Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function PricingTable() {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Transparent Pricing</h2>
          <p className="mt-4 text-xl text-slate-600 max-w-3xl mx-auto">
            Choose the plan that fits your business needs and growth goals.
          </p>
        </div>

        <div className="grid gap-6 lg:grid-cols-3 lg:gap-8">
          {/* Standard Plan */}
          <Card className="flex flex-col">
            <CardHeader>
              <CardTitle className="text-2xl">Standard</CardTitle>
              <div className="mt-4">
                <span className="text-4xl font-bold">$1,997</span>
                <span className="text-slate-600 ml-2">setup</span>
                <p className="text-slate-600 mt-1">+ $297/month</p>
              </div>
            </CardHeader>
            <CardContent className="flex-grow">
              <ul className="space-y-3">
                {[
                  "Custom website (5 pages)",
                  "Basic SEO setup",
                  "Social media integration",
                  "Email marketing setup",
                  "Google Business Profile optimization",
                  "Monthly performance report",
                ].map((feature, index) => (
                  <li key={index} className="flex items-center">
                    <Check className="h-5 w-5 text-emerald-500 mr-2 flex-shrink-0" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
            <CardFooter>
              <Button className="w-full">Get Started</Button>
            </CardFooter>
          </Card>

          {/* Professional Plan */}
          <Card className="flex flex-col border-emerald-200 shadow-lg relative">
            <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-emerald-600 text-white px-4 py-1 rounded-full text-sm font-medium">
              Most Popular
            </div>
            <CardHeader>
              <CardTitle className="text-2xl">Professional</CardTitle>
              <div className="mt-4">
                <span className="text-4xl font-bold">$2,997</span>
                <span className="text-slate-600 ml-2">setup</span>
                <p className="text-slate-600 mt-1">+ $397/month</p>
              </div>
            </CardHeader>
            <CardContent className="flex-grow">
              <ul className="space-y-3">
                {[
                  "Custom website (10 pages)",
                  "Advanced SEO optimization",
                  "Social media management",
                  "Email marketing automation",
                  "Google & Bing Ads setup",
                  "Review management system",
                  "Lead capture forms",
                  "CRM integration",
                  "Weekly performance reports",
                ].map((feature, index) => (
                  <li key={index} className="flex items-center">
                    <Check className="h-5 w-5 text-emerald-500 mr-2 flex-shrink-0" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
            <CardFooter>
              <Button className="w-full bg-emerald-600 hover:bg-emerald-700">Get Started</Button>
            </CardFooter>
          </Card>

          {/* Enterprise Plan */}
          <Card className="flex flex-col">
            <CardHeader>
              <CardTitle className="text-2xl">Enterprise</CardTitle>
              <div className="mt-4">
                <span className="text-4xl font-bold">$4,997</span>
                <span className="text-slate-600 ml-2">setup</span>
                <p className="text-slate-600 mt-1">+ $497/month</p>
              </div>
            </CardHeader>
            <CardContent className="flex-grow">
              <ul className="space-y-3">
                {[
                  "Custom website (unlimited pages)",
                  "Comprehensive SEO strategy",
                  "Full social media management",
                  "Advanced marketing automation",
                  "Complete ad campaign management",
                  "AI chatbot integration",
                  "Custom CRM workflow setup",
                  "Reputation management",
                  "Content creation",
                  "Dedicated account manager",
                  "Priority support",
                  "Weekly strategy calls",
                ].map((feature, index) => (
                  <li key={index} className="flex items-center">
                    <Check className="h-5 w-5 text-emerald-500 mr-2 flex-shrink-0" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
            <CardFooter>
              <Button className="w-full">Get Started</Button>
            </CardFooter>
          </Card>
        </div>

        <div className="mt-8 text-center">
          <p className="text-slate-600">
            All plans include our 90-day satisfaction guarantee. If you're not seeing results after following our
            program, we'll provide an additional month of service at no charge.
          </p>
        </div>
      </div>
    </section>
  )
}

