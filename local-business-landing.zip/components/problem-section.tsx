"use client"

import { motion } from "framer-motion"
import { AlertCircle, Frown, BarChart3, Clock } from "lucide-react"

export default function ProblemSection() {
  const problems = [
    {
      icon: <AlertCircle className="w-6 h-6 text-red-400" />,
      title: "Overwhelmed by Inefficient Systems",
      description: "Juggling multiple tools that don't work together wastes your time and energy",
    },
    {
      icon: <BarChart3 className="w-6 h-6 text-red-400" />,
      title: "Unpredictable Lead Flow",
      description: "The feast-or-famine cycle of customers makes planning impossible",
    },
    {
      icon: <Frown className="w-6 h-6 text-red-400" />,
      title: "Fierce Competition",
      description: "Watching competitors thrive while you're stuck in the same old routine",
    },
    {
      icon: <Clock className="w-6 h-6 text-red-400" />,
      title: "Wasted Resources",
      description: "Spending money on marketing that doesn't deliver measurable results",
    },
  ]

  return (
    <section className="py-20 bg-navy-950">
      <div className="container mx-auto px-4">
        <motion.div
          className="text-center max-w-3xl mx-auto mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-white">We Understand Your Struggle</h2>
          <div className="inline-block px-6 py-3 bg-navy-800 text-red-400 rounded-lg text-lg font-bold mb-6">
            87% of local business owners feel overwhelmed
          </div>
          <p className="text-lg text-gray-300">
            You're tired of outdated tactics that drain your resources and hide your true potential. It's time to break
            free from this cycle.
          </p>
          <p className="text-lg text-gray-300 mt-4">
            We know your challenges—juggling multiple tools, fighting for local visibility, and the anxiety of watching
            competitors thrive while you're stuck in the same old routine.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8">
          {problems.map((problem, index) => (
            <motion.div
              key={index}
              className="bg-navy-900 rounded-xl p-6 border border-navy-800 flex gap-4 items-start"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <div className="w-12 h-12 bg-navy-800 rounded-full flex items-center justify-center flex-shrink-0">
                {problem.icon}
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2 text-white">{problem.title}</h3>
                <p className="text-gray-300">{problem.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

