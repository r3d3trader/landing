"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Users, ArrowRight } from "lucide-react"

export default function ScarcitySection() {
  const [timeLeft, setTimeLeft] = useState({
    days: 2,
    hours: 23,
    minutes: 59,
    seconds: 59,
  })

  const [viewers, setViewers] = useState(17)

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        const newSeconds = prev.seconds - 1
        if (newSeconds >= 0) return { ...prev, seconds: newSeconds }

        const newMinutes = prev.minutes - 1
        if (newMinutes >= 0) return { ...prev, minutes: newMinutes, seconds: 59 }

        const newHours = prev.hours - 1
        if (newHours >= 0) return { ...prev, hours: newHours, minutes: 59, seconds: 59 }

        const newDays = prev.days - 1
        if (newDays >= 0) return { days: newDays, hours: 23, minutes: 59, seconds: 59 }

        clearInterval(timer)
        return { days: 0, hours: 0, minutes: 0, seconds: 0 }
      })
    }, 1000)

    // Simulate random viewers
    const viewerInterval = setInterval(() => {
      setViewers((prev) => {
        const change = Math.random() > 0.7 ? 1 : 0
        return Math.min(Math.max(prev + (Math.random() > 0.5 ? change : -change), 12), 24)
      })
    }, 5000)

    return () => {
      clearInterval(timer)
      clearInterval(viewerInterval)
    }
  }, [])

  return (
    <section className="py-16 bg-navy-950">
      <div className="container mx-auto px-4">
        <motion.div
          className="max-w-4xl mx-auto bg-navy-900 rounded-xl p-8 border border-navy-800"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <div className="text-center mb-8">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white">
              Only 5 Spots Left – Claim Your Breakthrough Blueprint Now!
            </h2>
            <p className="text-lg text-gray-300">
              The clock is ticking. Don't miss your chance to transform your local business.
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            {[
              { label: "Days", value: timeLeft.days },
              { label: "Hours", value: timeLeft.hours },
              { label: "Minutes", value: timeLeft.minutes },
              { label: "Seconds", value: timeLeft.seconds },
            ].map((item, index) => (
              <div key={index} className="bg-navy-800 rounded-lg p-4 text-center border border-navy-700">
                <div className="text-3xl md:text-4xl font-bold text-white mb-1">
                  {item.value < 10 ? `0${item.value}` : item.value}
                </div>
                <div className="text-sm text-gray-300">{item.label}</div>
              </div>
            ))}
          </div>

          <div className="flex items-center justify-center gap-2 mb-8 text-gray-300">
            <Users className="w-5 h-5 text-blue-400" />
            <span>{viewers} people are viewing this offer right now</span>
          </div>

          <div className="text-center">
            <Button className="bg-blue-500 hover:bg-blue-600 text-white font-bold rounded-md py-6 px-8 text-lg flex items-center gap-2 group mx-auto">
              Secure Your Elite Spot Now
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

