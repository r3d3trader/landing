"use client"

import { motion } from "framer-motion"
import { Check } from "lucide-react"

const services = [
  {
    name: "Conversion – Super Sales Machine",
    description: "Expected Sales and Conversions at a supercharged level",
    value: "$800",
  },
  {
    name: "Pages Setup / Website Setup",
    description:
      "Fully customized premium website with tailored UX/UI, multimedia-rich Knowledge Base, and advanced design elements",
    value: "$1,200",
  },
  {
    name: "Custom Website Creation",
    description:
      "Bespoke website creation with tailor-made design, interactive elements, and premium conversion tactics",
    value: "$1,000",
  },
  {
    name: "Bot Automation",
    description: "Fully customized AI bot solution with bespoke training and seamless multi-channel integration",
    value: "$600",
  },
  {
    name: "Abandoned Cart/Action Triggers",
    description: "Enterprise-grade triggers with advanced segmentation and real-time recovery strategies",
    value: "$700",
  },
  {
    name: "Email Sequences/Automation",
    description: "High-impact, behavior-triggered email campaigns with fully customized workflows",
    value: "$800",
  },
  {
    name: "Reputation Management",
    description: "Comprehensive real-time reputation management with proactive response systems",
    value: "$500",
  },
  {
    name: "Workflow Automation",
    description: "End-to-end custom workflow automation with sophisticated, multi-step processes",
    value: "$800",
  },
  {
    name: "Landing Pages",
    description: "Premium landing pages featuring value stacking, multimedia integration, and tailored messaging",
    value: "$600",
  },
  {
    name: "Squeeze Pages",
    description: "Fully optimized, high-conversion squeeze pages designed with advanced persuasion techniques",
    value: "$400",
  },
  {
    name: "Lead Magnet Creation",
    description: "Advanced, custom lead magnet strategies with high perceived value and professional design",
    value: "$400",
  },
  {
    name: "Webinar Automation",
    description: "Full-scale webinar automation with premium funnel integration and robust follow-up sequences",
    value: "$700",
  },
]

export default function ServiceBreakdown() {
  return (
    <section className="py-20 bg-navy-900">
      <div className="container mx-auto px-4">
        <motion.div
          className="text-center max-w-3xl mx-auto mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-white">Elite Program Breakdown</h2>
          <p className="text-lg text-gray-300">
            A detailed look at everything included in your Elite Program investment.
          </p>

          <div className="mt-8 inline-block bg-navy-800 rounded-lg p-6 border border-dashed border-navy-700">
            <div className="grid grid-cols-2 gap-4 text-left">
              <div>
                <h3 className="text-lg font-bold text-white">Setup Fee</h3>
                <p className="text-2xl font-bold text-blue-400">$4,997 USD</p>
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">Monthly Fee</h3>
                <p className="text-2xl font-bold text-blue-400">$497 USD</p>
              </div>
            </div>
          </div>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => (
            <motion.div
              key={index}
              className="bg-navy-800 rounded-lg p-6 border border-dashed border-navy-700 hover:border-blue-500/30 transition-all"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.05 }}
            >
              <div className="flex justify-between items-start mb-4">
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <Check className="w-5 h-5 text-blue-400 flex-shrink-0" />
                  {service.name}
                </h3>
                <div className="text-lg font-bold text-blue-400">{service.value}</div>
              </div>
              <p className="text-gray-300">{service.description}</p>
            </motion.div>
          ))}
        </div>

        <motion.div
          className="mt-12 text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.3 }}
        >
          <div className="inline-block px-6 py-3 bg-navy-800 text-blue-400 rounded-lg text-lg font-bold border border-dashed border-navy-700">
            Total Perceived Value of Elite Services: ~$16,500+ USD
          </div>
        </motion.div>
      </div>
    </section>
  )
}

