"use client"

import { motion } from "framer-motion"
import { Sparkles, Users, Rocket, BarChart } from "lucide-react"

export default function SolutionSection() {
  return (
    <section className="py-20 bg-navy-900">
      <div className="container mx-auto px-4">
        <motion.div
          className="text-center max-w-3xl mx-auto mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <div className="inline-block px-6 py-3 bg-navy-800 rounded-lg text-lg font-bold mb-6 border border-navy-700">
            The Grand Slam Reveal
          </div>
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-white">Breakthrough 90 Blueprint Elite Program</h2>
          <p className="text-lg text-gray-300">
            After empowering over 1,200 local businesses, we proudly present the 'Breakthrough 90 Blueprint' Elite
            Program—a complete system designed to automate your marketing, supercharge your website, and double your
            customer base in just 90 days.
          </p>
          <p className="text-lg text-gray-300 mt-4">
            This isn't a generic service. It's a bespoke, high-impact solution crafted for local businesses that demand
            excellence and rapid results.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {[
            {
              icon: <Rocket className="w-8 h-8 text-blue-400" />,
              title: "90-Day Transformation",
              description: "A proven system to revolutionize your business in just 3 months",
            },
            {
              icon: <Users className="w-8 h-8 text-blue-400" />,
              title: "Double Your Customers",
              description: "Strategies that consistently bring in qualified local leads",
            },
            {
              icon: <BarChart className="w-8 h-8 text-blue-400" />,
              title: "Measurable Results",
              description: "Clear metrics and reporting to track your ROI",
            },
            {
              icon: <Sparkles className="w-8 h-8 text-blue-400" />,
              title: "Bespoke Solution",
              description: "Custom-tailored to your specific local business needs",
            },
          ].map((feature, index) => (
            <motion.div
              key={index}
              className="bg-navy-800 rounded-xl p-6 border border-navy-700 hover:border-blue-500/30 transition-all"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <div className="w-16 h-16 bg-navy-700 rounded-full flex items-center justify-center mb-6 border border-navy-600">
                {feature.icon}
              </div>
              <h3 className="text-xl font-bold mb-3 text-white">{feature.title}</h3>
              <p className="text-gray-300">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

