"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { ChevronLeft, ChevronRight, Quote } from "lucide-react"

const testimonials = [
  {
    name: "Sarah Johnson",
    business: "Boutique Owner",
    quote:
      "The marketing program helped us increase our foot traffic by 45% in just three months. The team was responsive and really understood our local market.",
    image: "/placeholder.svg?height=100&width=100",
  },
  {
    name: "Mark Davis",
    business: "Café Owner",
    quote:
      "Their digital strategy transformed our online presence and significantly increased our bookings. The ROI has been excellent.",
    image: "/placeholder.svg?height=100&width=100",
  },
  {
    name: "Jennifer Smith",
    business: "Dental Practice",
    quote:
      "We've seen a steady increase in new patients since implementing their marketing recommendations. Their local SEO expertise is outstanding.",
    image: "/placeholder.svg?height=100&width=100",
  },
]

export default function TestimonialCarousel() {
  const [current, setCurrent] = useState(0)
  const [autoplay, setAutoplay] = useState(true)

  const next = () => {
    setCurrent((current + 1) % testimonials.length)
  }

  const prev = () => {
    setCurrent((current - 1 + testimonials.length) % testimonials.length)
  }

  useEffect(() => {
    if (!autoplay) return

    const interval = setInterval(() => {
      next()
    }, 5000)

    return () => clearInterval(interval)
  }, [current, autoplay])

  return (
    <section className="py-16 bg-slate-50">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Success Stories</h2>
          <p className="mt-4 text-xl text-slate-600 max-w-3xl mx-auto">
            Hear from local business owners who have transformed their operations with our help.
          </p>
        </div>

        <div className="relative max-w-4xl mx-auto">
          <div
            className="absolute left-4 top-1/2 -translate-y-1/2 z-10 cursor-pointer bg-white rounded-full p-2 shadow-md"
            onClick={() => {
              prev()
              setAutoplay(false)
            }}
          >
            <ChevronLeft className="h-6 w-6" />
          </div>

          <div className="overflow-hidden">
            <div
              className="flex transition-transform duration-500 ease-in-out"
              style={{ transform: `translateX(-${current * 100}%)` }}
            >
              {testimonials.map((testimonial, index) => (
                <div key={index} className="w-full flex-shrink-0">
                  <Card className="border-0 shadow-lg">
                    <CardContent className="p-8">
                      <div className="flex flex-col items-center text-center space-y-4">
                        <div className="relative">
                          <Quote className="h-10 w-10 text-emerald-500 opacity-20 absolute -top-4 -left-4" />
                          <img
                            src={testimonial.image || "/placeholder.svg"}
                            alt={testimonial.name}
                            className="h-20 w-20 rounded-full object-cover"
                          />
                        </div>
                        <p className="text-lg text-slate-700 italic">"{testimonial.quote}"</p>
                        <div>
                          <h4 className="font-bold text-lg">{testimonial.name}</h4>
                          <p className="text-slate-600">{testimonial.business}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              ))}
            </div>
          </div>

          <div
            className="absolute right-4 top-1/2 -translate-y-1/2 z-10 cursor-pointer bg-white rounded-full p-2 shadow-md"
            onClick={() => {
              next()
              setAutoplay(false)
            }}
          >
            <ChevronRight className="h-6 w-6" />
          </div>

          <div className="flex justify-center mt-6 space-x-2">
            {testimonials.map((_, index) => (
              <button
                key={index}
                className={`h-2 w-2 rounded-full ${current === index ? "bg-emerald-600" : "bg-slate-300"}`}
                onClick={() => {
                  setCurrent(index)
                  setAutoplay(false)
                }}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

