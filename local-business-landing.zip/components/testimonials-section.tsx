"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { ChevronLeft, ChevronRight, Star, Quote } from "lucide-react"

const testimonials = [
  {
    name: "Sarah Johnson",
    business: "Boutique Owner",
    quote:
      "Our foot traffic increased by 120% in just three months! The Elite program transformed our online presence and brought in customers we never would have reached otherwise.",
    image: "/placeholder.svg?height=100&width=100",
    stars: 5,
  },
  {
    name: "Mark Davis",
    business: "Café Owner",
    quote:
      "The Elite program transformed our online presence and doubled our bookings! Their team understood exactly what our local café needed to stand out.",
    image: "/placeholder.svg?height=100&width=100",
    stars: 5,
  },
  {
    name: "Jennifer Smith",
    business: "Dental Practice",
    quote:
      "We've seen a 95% increase in new patients since implementing their marketing recommendations. Their local SEO expertise is outstanding and the automation saves us hours every week.",
    image: "/placeholder.svg?height=100&width=100",
    stars: 5,
  },
]

export default function TestimonialsSection() {
  const [current, setCurrent] = useState(0)
  const [autoplay, setAutoplay] = useState(true)

  const next = () => {
    setCurrent((current + 1) % testimonials.length)
  }

  const prev = () => {
    setCurrent((current - 1 + testimonials.length) % testimonials.length)
  }

  useEffect(() => {
    if (!autoplay) return

    const interval = setInterval(() => {
      next()
    }, 5000)

    return () => clearInterval(interval)
  }, [current, autoplay])

  return (
    <section id="testimonials" className="py-20 bg-navy-900">
      <div className="container mx-auto px-4">
        <motion.div
          className="text-center max-w-3xl mx-auto mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-white">
            Local Leaders Who Transformed Their Business
          </h2>
          <p className="text-lg text-gray-300">
            Hear from business owners just like you who have experienced the Breakthrough transformation.
          </p>
        </motion.div>

        <div className="relative max-w-4xl mx-auto">
          <button
            className="absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-navy-800 rounded-full p-3 shadow-lg text-white hover:bg-navy-700 transition-colors"
            onClick={() => {
              prev()
              setAutoplay(false)
            }}
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          <div className="overflow-hidden px-12">
            <div
              className="flex transition-transform duration-500 ease-in-out"
              style={{ transform: `translateX(-${current * 100}%)` }}
            >
              {testimonials.map((testimonial, index) => (
                <div key={index} className="w-full flex-shrink-0 px-4">
                  <motion.div
                    className="bg-navy-800 rounded-xl p-8 border border-navy-700"
                    initial={{ opacity: 0, scale: 0.95 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5 }}
                  >
                    <div className="flex flex-col items-center text-center">
                      <div className="relative mb-6">
                        <Quote className="absolute -top-2 -left-2 w-8 h-8 text-blue-400 transform -scale-x-100" />
                        <div className="w-24 h-24 rounded-full overflow-hidden border-4 border-navy-700">
                          <img
                            src={testimonial.image || "/placeholder.svg"}
                            alt={testimonial.name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                      </div>

                      <div className="flex mb-4">
                        {[...Array(testimonial.stars)].map((_, i) => (
                          <Star key={i} className="w-5 h-5 text-yellow-400 fill-yellow-400" />
                        ))}
                      </div>

                      <p className="text-lg text-gray-300 italic mb-6">"{testimonial.quote}"</p>

                      <div>
                        <h4 className="text-xl font-bold text-white">{testimonial.name}</h4>
                        <p className="text-blue-400">{testimonial.business}</p>
                      </div>
                    </div>
                  </motion.div>
                </div>
              ))}
            </div>
          </div>

          <button
            className="absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-navy-800 rounded-full p-3 shadow-lg text-white hover:bg-navy-700 transition-colors"
            onClick={() => {
              next()
              setAutoplay(false)
            }}
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          <div className="flex justify-center mt-8 space-x-2">
            {testimonials.map((_, index) => (
              <button
                key={index}
                className={`h-3 w-3 rounded-full transition-colors ${
                  current === index ? "bg-blue-500" : "bg-navy-700"
                }`}
                onClick={() => {
                  setCurrent(index)
                  setAutoplay(false)
                }}
              />
            ))}
          </div>
        </div>

        <motion.div
          className="mt-12 text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.3 }}
        >
          <div className="inline-block px-6 py-3 bg-navy-800 text-blue-400 rounded-lg text-lg font-bold">
            20/25 Spots Claimed – Join the Local Business Elite Today!
          </div>
        </motion.div>
      </div>
    </section>
  )
}

