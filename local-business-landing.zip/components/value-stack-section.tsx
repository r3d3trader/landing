"use client"

import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Gift, Shield, ArrowRight } from "lucide-react"

export default function ValueStackSection() {
  return (
    <section className="py-20 bg-navy-950">
      <div className="container mx-auto px-4">
        <motion.div
          className="text-center max-w-3xl mx-auto mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-white">Your Ultimate Local Domination Package</h2>
          <p className="text-lg text-gray-300">
            Everything you need to transform your local business and dominate your market.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          <motion.div
            className="space-y-8"
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            {/* Core Offer */}
            <div className="bg-navy-900 rounded-xl p-8 border border-navy-800 relative">
              <div className="absolute -top-4 left-8 bg-blue-500 text-white px-4 py-1 rounded-md text-sm font-bold">
                CORE OFFER
              </div>
              <h3 className="text-2xl font-bold text-white mt-2 mb-4">Breakthrough 90 Blueprint Elite</h3>
              <p className="text-gray-300 mb-6">
                A comprehensive, fully customized marketing and digital transformation system that propels your local
                business to the forefront of your community.
              </p>
              <div className="text-xl font-bold text-blue-400">Perceived Value: $16,500+</div>
            </div>

            {/* Bonuses */}
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-white">
                <Gift className="inline-block w-6 h-6 mr-2 text-blue-400" />
                Exclusive Bonuses
              </h3>

              {/* Bonus 1 */}
              <motion.div
                className="bg-navy-900 rounded-xl p-6 border border-dashed border-navy-700 hover:border-blue-500/30 transition-all"
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.3, delay: 0.1 }}
              >
                <div className="flex justify-between items-start mb-4">
                  <h4 className="text-xl font-bold text-white">Elite Business Growth Strategy Session</h4>
                  <div className="text-lg font-bold text-blue-400">$2,997 value</div>
                </div>
                <p className="text-gray-300">
                  A one-on-one 45-minute consultation with our founder and digital strategist to develop a customized
                  growth roadmap specifically for your business. This session will identify untapped revenue
                  opportunities, analyze competitor weaknesses you can exploit, and create a 12-month action plan.
                </p>
              </motion.div>

              {/* Bonus 2 */}
              <motion.div
                className="bg-navy-900 rounded-xl p-6 border border-dashed border-navy-700 hover:border-blue-500/30 transition-all"
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.3, delay: 0.2 }}
              >
                <div className="flex justify-between items-start mb-4">
                  <h4 className="text-xl font-bold text-white">AI Employee Assistant System</h4>
                  <div className="text-lg font-bold text-blue-400">$3,997 value</div>
                </div>
                <p className="text-gray-300">
                  Your business gets a dedicated AI employee that works 24/7 to automate crucial workflows and
                  communications. This intelligent system continuously gathers and organizes information from calls,
                  bookings, emails, and social messages to create a seamless customer experience.
                </p>
              </motion.div>

              {/* Bonus 3 */}
              <motion.div
                className="bg-navy-900 rounded-xl p-6 border border-dashed border-navy-700 hover:border-blue-500/30 transition-all"
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.3, delay: 0.3 }}
              >
                <div className="flex justify-between items-start mb-4">
                  <h4 className="text-xl font-bold text-white">Expedited Priority Build</h4>
                  <div className="text-lg font-bold text-blue-400">$1,997 value</div>
                </div>
                <p className="text-gray-300">
                  You get your whole Sales machine built in just 1-2 weeks, (even quicker in some cases). Unlike
                  traditional agencies that take up to 3 months to get you started, you get the benefits quicker. We get
                  our whole team to prioritize your build.
                </p>
              </motion.div>
            </div>

            {/* Guarantee */}
            <motion.div
              className="bg-navy-900 rounded-xl p-8 border border-navy-800"
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.3, delay: 0.4 }}
            >
              <div className="flex items-start gap-4">
                <Shield className="w-12 h-12 text-blue-400 flex-shrink-0" />
                <div>
                  <h3 className="text-2xl font-bold text-white mb-2">Risk-Reversal Rocket Guarantee</h3>
                  <p className="text-gray-300 mb-4">
                    Experience measurable improvements in 90 days or receive an extra month of coaching free—with a full
                    refund if you're not thrilled.
                  </p>
                  <div className="text-xl font-bold text-blue-400">Perceived Value: Priceless</div>
                </div>
              </div>
            </motion.div>
          </motion.div>

          <motion.div
            className="lg:sticky lg:top-24"
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <div className="bg-navy-900 rounded-xl p-8 border border-dashed border-navy-700">
              <h3 className="text-2xl font-bold text-white mb-6">Value Summary</h3>

              <div className="space-y-4 mb-8">
                <div className="flex justify-between items-center pb-2 border-b border-navy-800">
                  <span className="text-gray-300">Core Offer</span>
                  <span className="font-bold text-white">$16,500+</span>
                </div>
                <div className="flex justify-between items-center pb-2 border-b border-navy-800">
                  <span className="text-gray-300">Elite Business Growth Strategy</span>
                  <span className="font-bold text-white">$2,997</span>
                </div>
                <div className="flex justify-between items-center pb-2 border-b border-navy-800">
                  <span className="text-gray-300">AI Employee Assistant</span>
                  <span className="font-bold text-white">$3,997</span>
                </div>
                <div className="flex justify-between items-center pb-2 border-b border-navy-800">
                  <span className="text-gray-300">Expedited Priority Build</span>
                  <span className="font-bold text-white">$1,997</span>
                </div>
                <div className="flex justify-between items-center pb-2 border-b border-navy-800">
                  <span className="text-gray-300">Risk-Reversal Guarantee</span>
                  <span className="font-bold text-white">Priceless</span>
                </div>
                <div className="flex justify-between items-center pt-2 text-xl font-bold">
                  <span className="text-blue-400">Total Value</span>
                  <span className="text-blue-400">$25,491+</span>
                </div>
              </div>

              <div className="bg-blue-500 rounded-lg p-6 text-white mb-8">
                <h4 className="text-xl font-bold mb-2">Your Elite Investment:</h4>
                <div className="flex justify-between items-center mb-2">
                  <span>Setup Fee</span>
                  <span className="text-2xl font-bold">$4,997</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Monthly Fee</span>
                  <span className="text-xl font-bold">$497/month</span>
                </div>
              </div>

              <div className="space-y-4">
                <Button className="w-full bg-blue-500 hover:bg-blue-600 text-white font-bold rounded-md py-6 text-lg flex items-center justify-center gap-2 group">
                  Secure Your Elite Spot Now
                  <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </Button>
                <p className="text-center text-sm text-gray-400">Limited to 25 spots - Only 5 remaining!</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

